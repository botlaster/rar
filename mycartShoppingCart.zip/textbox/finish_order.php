<html>
<head>
<title>ThaiCreate.Com</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
Finish Your Order. <br><br>

<a href="view_order.php?OrderID=<?php echo $_GET["OrderID"];?>">View Order</a>

</body>
</html>

<?php /* This code download from www.ThaiCreate.Com */ ?>